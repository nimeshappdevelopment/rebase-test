<template>
  <div id="app">
    <question-one/>
    <QUestionTwo />
    <QuestionThree />
  </div>
</template>

<script>
import QuestionOne from './QuestionOne.vue'
import QuestionThree from './QuestionThree.vue'
import QUestionTwo from './QUestionTwo.vue'
export default {
  name: 'App',
  components: {
    QuestionOne,
    QuestionThree,
    QUestionTwo
  },
}
</script>

<style>
</style>
