<template>
  <div id="app">
      <h1>Question Two</h1>
      <p>{{new Date().toLocaleString()}}</p>
  </div>
</template>

<script>
export default {
  name: 'App',
  components: {
  },
}
</script>

<style>
</style>
